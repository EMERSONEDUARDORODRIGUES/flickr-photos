#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate SEO-optimized gallery page and image sitemap from a CSV of Flickr photos.

CSV required columns:
photo_url, image_direct_url, title_pt, title_en, title_es, desc_pt, desc_en, desc_es, tags

Usage:
    python generate_from_csv.py photos.csv --site-dir ./site --base-url https://YOUR-DOMAIN
"""
import argparse, csv, os, json, html, datetime, hashlib
from pathlib import Path

def slugify(s: str) -> str:
    s = s.lower().strip()
    for ch in " /\\?%*:|\"<>#&'":
        s = s.replace(ch, "-")
    while "--" in s:
        s = s.replace("--", "-")
    return s.strip("-")

def build_jsonld(items, base_url):
    # Create a JSON-LD ImageGallery with ImageObject entries
    images = []
    for it in items:
        images.append({
            "@type": "ImageObject",
            "contentUrl": it["image_direct_url"],
            "url": it["photo_url"],
            "name": it["title_en"] or it["title_pt"] or it["title_es"],
            "caption": it["desc_en"] or it["desc_pt"] or it["desc_es"],
            "keywords": it["tags"]
        })
    data = {
        "@context": "https://schema.org",
        "@type": "ImageGallery",
        "name": "Official Gallery - Emerson Eduardo Rodrigues",
        "url": base_url.rstrip("/"),
        "image": images
    }
    return json.dumps(data, ensure_ascii=False, indent=2)

def generate_html(items, out_html, base_url):
    head = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Official Photos – Emerson Eduardo Rodrigues</title>
  <meta name="description" content="Official photos and projects of Emerson Eduardo Rodrigues (Engineer & IT Specialist).">
  <link rel="canonical" href="{base_url.rstrip('/')}">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Official Photos – Emerson Eduardo Rodrigues">
  <meta property="og:description" content="Official photos and projects of Emerson Eduardo Rodrigues (Engineer & IT Specialist).">
  <meta property="og:url" content="{base_url.rstrip('/')}">
  <meta name="twitter:card" content="summary_large_image">
  <script type="application/ld+json">
{build_jsonld(items, base_url)}
  </script>
  <style>
    body {{ font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 0; background: #0b0c10; color: #eaeaea; }}
    header {{ padding: 32px 16px; text-align: center; }}
    h1 {{ margin: 0 0 8px; font-weight: 700; }}
    p.lead {{ opacity: 0.9; margin: 0; }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; padding: 16px; }}
    .card {{ background: #11131a; border: 1px solid #1d2233; border-radius: 16px; overflow: hidden; box-shadow: 0 2px 16px rgba(0,0,0,.35); }}
    .card img {{ width: 100%; height: 240px; object-fit: cover; display: block; }}
    .card .inner {{ padding: 12px 14px; }}
    .tagz {{ font-size: 12px; opacity: 0.8; }}
    footer {{ text-align: center; padding: 32px 16px; opacity: 0.7; }}
    a {{ color: #8bb9ff; text-decoration: none; }}
    a:hover {{ text-decoration: underline; }}
  </style>
</head>
<body>
  <header>
    <h1>Official Photos – Emerson Eduardo Rodrigues</h1>
    <p class="lead">Curated gallery linking to original Flickr sources. Multilingual titles and descriptions included.</p>
  </header>
  <main class="grid">
"""
    cards = []
    for it in items:
        tpt = html.escape(it["title_pt"])
        ten = html.escape(it["title_en"])
        tes = html.escape(it["title_es"])
        dpt = html.escape(it["desc_pt"])
        den = html.escape(it["desc_en"])
        des = html.escape(it["desc_es"])
        tags = html.escape(it["tags"])
        img = html.escape(it["image_direct_url"])
        flickr = html.escape(it["photo_url"])
        alt = html.escape(f"{ten or tpt or tes} | {den or dpt or des}")
        cards.append(f"""
    <article class="card">
      <a href="{flickr}" target="_blank" rel="noopener nofollow">
        <img src="{img}" alt="{alt}">
      </a>
      <div class="inner">
        <strong>PT:</strong> {tpt}<br>
        <strong>EN:</strong> {ten}<br>
        <strong>ES:</strong> {tes}
        <p class="tagz">{tags}</p>
        <p><a href="{flickr}" target="_blank" rel="noopener nofollow">View on Flickr</a></p>
      </div>
    </article>
""")
    tail = """
  </main>
  <footer>© """ + str(datetime.datetime.utcnow().year) + """ · Emerson Eduardo Rodrigues · All rights reserved.</footer>
</body>
</html>
"""
    Path(out_html).write_text(head + "".join(cards) + tail, encoding="utf-8")

def generate_image_sitemap(items, out_xml, base_url):
    # Standard image sitemap with <image:image> entries
    urlset = ['<?xml version="1.0" encoding="UTF-8"?>',
              '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"',
              '        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">']
    homepage = base_url.rstrip("/")
    urlset.append(f'  <url><loc>{homepage}</loc></url>')
    for it in items:
        slug = slugify(it["title_en"] or it["title_pt"] or it["title_es"])
        page_url = f"{homepage}/#{slug}"
        urlset.append("  <url>")
        urlset.append(f"    <loc>{page_url}</loc>")
        urlset.append("    <image:image>")
        urlset.append(f"      <image:loc>{it['image_direct_url']}</image:loc>")
        title = (it["title_en"] or it["title_pt"] or it["title_es"]).strip()
        caption = (it["desc_en"] or it["desc_pt"] or it["desc_es"]).strip()
        urlset.append(f"      <image:title>{html.escape(title)}</image:title>")
        urlset.append(f"      <image:caption>{html.escape(caption)}</image:caption>")
        urlset.append("    </image:image>")
        urlset.append("  </url>")
    urlset.append("</urlset>")
    Path(out_xml).write_text("\n".join(urlset), encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv_path", help="CSV with photo metadata")
    ap.add_argument("--site-dir", default="./site", help="Output directory for site files")
    ap.add_argument("--base-url", required=True, help="Public URL where this gallery will be hosted (e.g., https://emerson.site)")
    args = ap.parse_args()

    site_dir = Path(args.site_dir)
    site_dir.mkdir(parents=True, exist_ok=True)

    items = []
    with open(args.csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Simple validation
            needed = ["photo_url","image_direct_url","title_pt","title_en","title_es","desc_pt","desc_en","desc_es","tags"]
            if not all(k in row for k in needed):
                raise SystemExit(f"CSV missing columns. Required: {needed}")
            items.append({k: (row.get(k) or "").strip() for k in needed})

    # Generate outputs
    generate_html(items, site_dir / "index.html", args.base_url)
    generate_image_sitemap(items, site_dir / "sitemap.xml", args.base_url)

    # robots.txt to allow crawling
    (site_dir / "robots.txt").write_text(
        "User-agent: *\nAllow: /\nSitemap: {}/sitemap.xml\n".format(args.base_url.rstrip("/")),
        encoding="utf-8"
    )

    print("Generated:", site_dir / "index.html")
    print("Generated:", site_dir / "sitemap.xml")
    print("Generated:", site_dir / "robots.txt")

if __name__ == "__main__":
    main()
