Flickr SEO Toolkit — Emerson Eduardo Rodrigues
=============================================

O que este kit faz
------------------
1) Você preenche o arquivo `photos_template.csv` com as URLs das suas fotos do Flickr e os textos multilíngues.
2) O script `generate_from_csv.py` lê o CSV e gera:
   - `site/index.html`: uma galeria com metadados SEO (Open Graph + JSON-LD ImageGallery).
   - `site/sitemap.xml`: sitemap de imagens para o Google.
   - `site/robots.txt`: liberando o crawl e apontando para o sitemap.

Como usar (passo a passo)
-------------------------
1) Edite `photos_template.csv`:
   - `photo_url`: URL da foto no Flickr (página pública).
   - `image_direct_url`: URL direta da imagem no CDN do Flickr (live.staticflickr.com/...).
   - Títulos e descrições em PT/EN/ES — use seu nome completo e palavras-chave (TI, Engenharia, Europa).
   - `tags`: separadas por vírgula.

2) Gere os arquivos do site:
   - No terminal local: `python generate_from_csv.py photos_template.csv --site-dir ./site --base-url https://SEU-DOMINIO`
   - O diretório `site/` terá `index.html`, `sitemap.xml` e `robots.txt` prontos.

3) Publique o site (opções simples e gratuitas):
   - **GitHub Pages**: crie um repositório, adicione a pasta `site/`, ative Pages.
   - **Netlify**: arraste a pasta `site/` para um novo site.
   - **Vercel**: crie um projeto estático com a pasta `site/`.

4) Fortalecer o ranqueamento (ação rápida):
   - Coloque o link do seu novo site na bio do **LinkedIn**, **Instagram**, **X** e **Facebook**.
   - Publique posts usando os modelos em `social_captions.csv` e substitua `{PHOTO_URL}` pela URL de cada foto.
   - Faça pelo menos 1-2 posts por semana, cada um linkando para uma foto diferente do Flickr.

Dicas
-----
- Use nomes de arquivo descritivos ao subir novas fotos no Flickr.
- Mantenha consistência: seu nome completo e cargos iguais em todas as plataformas.
- Atualize o CSV e gere um novo `index.html` quando adicionar novas fotos.

Observação
----------
Este kit não usa API do Flickr — você pode preencher as URLs manualmente.
Se desejar automação futura via API, podemos adicionar um script que coleta suas fotos usando a Flickr API key.

Arquivo gerado em: 2025-09-06T20:30:09.909539Z